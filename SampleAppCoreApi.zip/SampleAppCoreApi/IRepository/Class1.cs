﻿using System;

namespace IRepository
{
    public class Class1
    {
    }
}
