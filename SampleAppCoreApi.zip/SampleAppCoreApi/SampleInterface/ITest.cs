﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleInterface
{
    public interface ITest
    {
       void Load(string str);
    }
}
