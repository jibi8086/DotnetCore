﻿using SampleInterface;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleEntity
{
   public class Test: ITest
    {
        public void Load(string str) { }
    }
}
