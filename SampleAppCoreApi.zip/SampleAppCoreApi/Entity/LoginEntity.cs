﻿using API.Common;
using IRepository;
using SampleInterface;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleEntity
{
    public class LoginEntity : ILoginEntity
    {
        private readonly ILoginRepo _loginRepo;
        public LoginEntity(ILoginRepo loginRepo)
        {
            _loginRepo = loginRepo;   
        }
        public UserModel AuthenticateUser(UserModel login)
        {
            UserModel user = null;

            //Validate the User Credentials  
            //Demo Purpose, I have Passed HardCoded User Information  
            if (login.Username == "test")
            {
                user = new UserModel { Username = "Jignesh Trivedi", EmailAddress = "test.btest@gmail.com" };
            }
            _loginRepo.AuthenticateUser(login);
            return user;
        }

    }
}
