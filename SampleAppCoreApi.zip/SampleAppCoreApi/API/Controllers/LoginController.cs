﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using SampleInterface;

namespace API.Controllers
{
    [Route("api/login")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ILoginEntity _login;
        private readonly IConfiguration _config;
        public LoginController(ILoginEntity login, IConfiguration config)
        {
            _login = login;
            _config = config;
        }
        [HttpPost]
        [Route("SignUp")]
        public IActionResult SignUp(UserModel login)
        {
            try
            {
                IActionResult response = Unauthorized();
                var user = _login.AuthenticateUser(login);

                if (user != null)
                {
                    var tokenString = GenerateJSONWebToken(login);
                    login.Token = tokenString.ToString();
                    return Ok(new Envelope<UserModel>(true, "data-fetch-success", login));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }
        [HttpPost]
        [Route("getdata")]
        [Authorize]
        public  IActionResult GetData()
        {
            return null; 
        }

        private string GenerateJSONWebToken(UserModel userInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
              _config["Jwt:Issuer"],
              null,
              expires: DateTime.Now.AddMinutes(120),
              signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        [HttpPost]
        [Route("fileUplaod")]
        public async Task<IActionResult> OnPostUploadAsync(List<IFormFile> files)
        {
            long size = files.Sum(f => f.Length);
            var filePath = string.Empty;
            foreach (var formFile in files)
            {
                if (formFile.Length > 0)
                {
                      filePath = Path.GetTempFileName();

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await formFile.CopyToAsync(stream);
                    }
                }
            }
            try
            {
                System.IO.File.Move(filePath, "C:\\Users\\jibin.jh\\Downloads\\New folder\\Test1");
            }
            catch (Exception ex)
            {

                throw;
            }
            
           // MoveImage(filePath);
            // Process uploaded files
            // Don't rely on or trust the FileName property without validation.

            return Ok(new { count = files.Count, size, filePath });
        }
        [Route("get_image")]
        [HttpGet]
        public IActionResult Get()
        {
            Byte[] b = System.IO.File.ReadAllBytes(@"C:\\Users\\jibin.jh\\Downloads\\New folder\\Test1");   // You can use your own method over here.         
            return File(b, "image/jpeg");
        }
        public void MoveImage(string filePath) {

            String directoryName = filePath;
            DirectoryInfo dirInfo = new DirectoryInfo(directoryName);
            if (dirInfo.Exists == false)
                Directory.CreateDirectory(directoryName);

            List<String> MyMusicFiles = Directory
                               .GetFiles("E:\\Images", "*.*", SearchOption.AllDirectories).ToList();

            foreach (string file in MyMusicFiles)
            {
                FileInfo mFile = new FileInfo(file);
                // to remove name collisions
                if (new FileInfo(dirInfo + "\\" + mFile.Name).Exists == false)
                {
                    mFile.MoveTo(dirInfo + "\\" + mFile.Name);
                }
            }
        }

        public class Attachment
        {
            [Key]
            public string PortLogNo { get; set; }
            public string Description { get; set; }
            public string Item { get; set; }
            public byte[] File { get; set; }
            public string FileName { get; set; }
            public bool? Attached { get; set; }
        }
        public class AttachmentViewModel
        {
            public string PortLogNo { get; set; }
            public string Description { get; set; }
            public string File { get; set; }
            public string FileName { get; set; }
        }
    }
}