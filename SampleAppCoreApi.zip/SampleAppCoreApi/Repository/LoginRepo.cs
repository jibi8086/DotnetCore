﻿using API.Common;
using IRepository;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repository
{
    public class LoginRepo : ILoginRepo
    {
        public UserModel AuthenticateUser(UserModel login)
        {
            return login;
        }
    }
}
