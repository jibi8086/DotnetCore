﻿using System;

namespace API.Common
{
    public class Class1
    {
    }
}
