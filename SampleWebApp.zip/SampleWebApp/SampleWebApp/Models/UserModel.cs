﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleWebApp.Models
{
    public class UserModel
    {
        public string Username { get; set; }
        public string EmailAddress { get; set; }
        public string Token { get; set; }
        public string Passwd { get; set; }
    }
}
