﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SampleWebApp.Models;


namespace SampleWebApp.Controllers
{
    public class HomeController : Controller
    {
        //private const string URL = "https://localhost:44342/";
        private static readonly HttpClient _client;
        private readonly static string baseAddress = "https://localhost:44342/"; //EGATEConstants.BaseAddress;
                                                                                 //private string urlParameters = "?api_key=123";

        static HomeController()
        {
            _client = new HttpClient();
        }
        public  IActionResult Index()
        {
            UserModel login = new UserModel();
            login.EmailAddress= "test";
            login.Username = "test";
            try
            {
                
                var data1 = ProviderBase.PostAsync<UserModel>($"api/login/SignUp", login, string.Empty);
                login.Token = data1.Result.Data.Token;
                SetCookies(login, 1);

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return View();
        }

        public async Task<ActionResult> SetCookies(UserModel login, int? expireTime) {

            try
            {
                //int expireTime=(DateTime.Now).Ticks;
                CookieOptions option = new CookieOptions();
                if (expireTime.HasValue)
                    option.Expires = DateTime.Now.AddMinutes(expireTime.Value);
                else
                    option.Expires = DateTime.Now.AddMilliseconds(10);

                Response.Cookies.Append("token", login.Token, option);
                string token = this.Request.Cookies["token"];
                var data = await ProviderBase.PostAsync<long>($"api/login/SignUp", login, string.Empty);
                
                return Json(data);
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<ActionResult> About()
        {
            ViewData["Message"] = "Your application description page.";
            string token = Request.Cookies["token"];
            var data2 = await ProviderBase.GetAsync<long>($"api/login/getdata", token);
            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
